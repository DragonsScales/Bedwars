# Bedwars-Gens
Diamond and Emerald generators
